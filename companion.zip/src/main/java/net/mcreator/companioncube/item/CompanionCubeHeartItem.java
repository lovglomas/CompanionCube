
package net.mcreator.companioncube.item;

import net.minecraftforge.registries.ObjectHolder;

import net.minecraft.item.Rarity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Item;
import net.minecraft.block.BlockState;

import net.mcreator.companioncube.itemgroup.JustCompanionCubeItemGroup;
import net.mcreator.companioncube.CompanionCubeModElements;

@CompanionCubeModElements.ModElement.Tag
public class CompanionCubeHeartItem extends CompanionCubeModElements.ModElement {
	@ObjectHolder("companion_cube:companion_cube_heart")
	public static final Item block = null;
	public CompanionCubeHeartItem(CompanionCubeModElements instance) {
		super(instance, 1);
	}

	@Override
	public void initElements() {
		elements.items.add(() -> new ItemCustom());
	}
	public static class ItemCustom extends Item {
		public ItemCustom() {
			super(new Item.Properties().group(JustCompanionCubeItemGroup.tab).maxStackSize(64).rarity(Rarity.COMMON));
			setRegistryName("companion_cube_heart");
		}

		@Override
		public int getItemEnchantability() {
			return 0;
		}

		@Override
		public int getUseDuration(ItemStack itemstack) {
			return 0;
		}

		@Override
		public float getDestroySpeed(ItemStack par1ItemStack, BlockState par2Block) {
			return 1F;
		}
	}
}

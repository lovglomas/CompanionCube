
package net.mcreator.companioncube.itemgroup;

import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemGroup;

import net.mcreator.companioncube.block.CompanionCubeBlock;
import net.mcreator.companioncube.CompanionCubeModElements;

@CompanionCubeModElements.ModElement.Tag
public class JustCompanionCubeItemGroup extends CompanionCubeModElements.ModElement {
	public JustCompanionCubeItemGroup(CompanionCubeModElements instance) {
		super(instance, 4);
	}

	@Override
	public void initElements() {
		tab = new ItemGroup("tabjust_companion_cube") {
			@OnlyIn(Dist.CLIENT)
			@Override
			public ItemStack createIcon() {
				return new ItemStack(CompanionCubeBlock.block, (int) (1));
			}

			@OnlyIn(Dist.CLIENT)
			public boolean hasSearchBar() {
				return false;
			}
		};
	}
	public static ItemGroup tab;
}
